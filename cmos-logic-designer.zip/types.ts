
export type LogicType = 'AND' | 'OR' | 'VAR' | 'NOT';

export interface LogicNode {
  type: LogicType;
  value?: string;
  children?: LogicNode[];
}

export interface ComponentCoords {
  x: number;
  y: number;
  label: string;
  type: 'PMOS' | 'NMOS';
}

export interface NetworkStructure {
  pun: LogicNode;
  pdn: LogicNode;
  expression: string;
}
