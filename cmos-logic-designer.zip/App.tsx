
import React, { useState, useEffect, useCallback } from 'react';
import { LogicParser } from './services/logicParser';
import { explainCMOS } from './services/geminiService';
import { CircuitVisualizer } from './components/CircuitVisualizer';
import { TruthTable } from './components/TruthTable';
import { LogicNode } from './types';
import { 
  Zap, 
  Cpu, 
  History, 
  Send, 
  Info,
  Layers,
  FileCode,
  Terminal,
  Table as TableIcon
} from 'lucide-react';

const parser = new LogicParser();

const App: React.FC = () => {
  const [expression, setExpression] = useState('A . B');
  const [rootNode, setRootNode] = useState<LogicNode | null>(null);
  const [pun, setPun] = useState<LogicNode | null>(null);
  const [pdn, setPdn] = useState<LogicNode | null>(null);
  const [explanation, setExplanation] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<string[]>(['A . B', 'A + B', 'A ^ B', 'A ~ B', '(A.B) + C']);

  const handleGenerate = useCallback(async () => {
    if (!expression.trim()) return;
    
    setLoading(true);
    try {
      const parsedNode = parser.parse(expression);
      const generatedPdn = LogicParser.getPDN(parsedNode);
      const generatedPun = LogicParser.getPUN(parsedNode);

      setRootNode(parsedNode);
      setPdn(generatedPdn);
      setPun(generatedPun);

      const aiText = await explainCMOS(expression);
      setExplanation(aiText || '');
      
      if (!history.includes(expression)) {
        setHistory(prev => [expression, ...prev].slice(0, 10));
      }
    } catch (err) {
      console.error(err);
      alert("Invalid Boolean Expression. Use characters, '.', '+', '!', '^' (XOR), and '~' (XNOR).");
    } finally {
      setLoading(false);
    }
  }, [expression, history]);

  useEffect(() => {
    handleGenerate();
  }, []);

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-slate-50 overflow-x-hidden">
      <aside className="w-full lg:w-80 bg-slate-900 text-slate-100 p-6 flex flex-col border-r border-slate-800 shrink-0">
        <div className="flex items-center gap-3 mb-10">
          <div className="bg-green-500 p-2 rounded-xl shadow-lg shadow-green-500/20">
            <Cpu className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold leading-none text-white">CMOS VLSI</h1>
            <p className="text-[10px] text-green-400 font-bold tracking-widest uppercase mt-1">Logic Designer</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto space-y-8">
          <section>
            <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
              <History className="w-4 h-4" /> History
            </h2>
            <div className="space-y-2">
              {history.map((h, i) => (
                <button
                  key={i}
                  onClick={() => setExpression(h)}
                  className={`w-full text-left p-3 rounded-xl transition-all border mono text-sm truncate ${
                    expression === h 
                      ? 'bg-green-500/10 border-green-500/30 text-green-400' 
                      : 'bg-slate-800/50 border-transparent hover:bg-slate-800 text-slate-400'
                  }`}
                >
                  {h}
                </button>
              ))}
            </div>
          </section>

          <section className="bg-slate-800/30 p-4 rounded-2xl border border-slate-800">
            <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
              <Terminal className="w-4 h-4" /> Legend
            </h2>
            <div className="space-y-2 text-[11px]">
              <div className="flex justify-between items-center"><span className="text-slate-500 uppercase">AND</span><code className="text-green-400">A . B</code></div>
              <div className="flex justify-between items-center"><span className="text-slate-500 uppercase">OR</span><code className="text-green-400">A + B</code></div>
              <div className="flex justify-between items-center"><span className="text-slate-500 uppercase">XOR</span><code className="text-green-400">A ^ B</code></div>
              <div className="flex justify-between items-center"><span className="text-slate-500 uppercase">XNOR</span><code className="text-green-400">A ~ B</code></div>
            </div>
          </section>
        </div>
      </aside>

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="h-20 bg-white border-b border-slate-200 px-8 flex items-center justify-between shadow-sm z-10 shrink-0">
          <div className="flex-1 max-w-2xl flex gap-4">
            <div className="relative flex-1 group">
              <input
                type="text"
                value={expression}
                onChange={(e) => setExpression(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                placeholder="Expression (e.g. A . B)..."
                className="w-full pl-6 pr-14 py-3 bg-slate-50 border-2 border-slate-100 rounded-xl focus:border-green-500 focus:bg-white transition-all outline-none mono font-bold text-slate-700"
              />
              <button
                onClick={handleGenerate}
                disabled={loading}
                className="absolute right-2 top-2 bottom-2 px-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 transition-all flex items-center"
              >
                {loading ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Send className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 bg-slate-50 scroll-smooth">
          <div className="max-w-7xl mx-auto space-y-8 pb-12">
            
            {/* Top Grid: Schematic + Truth Table */}
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
              
              <div className="xl:col-span-8 space-y-4">
                <h3 className="text-sm font-black uppercase tracking-widest flex items-center gap-3 text-slate-400">
                  <Layers className="w-4 h-4 text-green-600" /> Static CMOS Schematic
                </h3>
                {pun && pdn ? (
                  <CircuitVisualizer pun={pun} pdn={pdn} expression={expression} />
                ) : (
                  <div className="h-[500px] bg-white rounded-2xl shadow-xl animate-pulse flex items-center justify-center text-slate-300">Generating Circuit...</div>
                )}
              </div>

              <div className="xl:col-span-4 space-y-4">
                <h3 className="text-sm font-black uppercase tracking-widest flex items-center gap-3 text-slate-400">
                  <TableIcon className="w-4 h-4 text-green-600" /> Logic Verification
                </h3>
                {rootNode && <TruthTable root={rootNode} />}
              </div>

            </div>

            {/* Bottom: Analysis */}
            <div className="space-y-4">
              <h3 className="text-sm font-black uppercase tracking-widest flex items-center gap-3 text-slate-400">
                <FileCode className="w-4 h-4 text-green-600" /> VLSI Analysis & Summary
              </h3>
              <div className="bg-white p-8 rounded-2xl shadow-xl border border-slate-200 relative overflow-hidden min-h-[200px]">
                <div className="absolute top-0 left-0 w-1.5 h-full bg-green-500"></div>
                {loading ? (
                  <div className="space-y-4">
                    <div className="h-4 bg-slate-100 rounded w-3/4 animate-pulse" />
                    <div className="h-4 bg-slate-100 rounded w-1/2 animate-pulse" />
                    <div className="h-24 bg-slate-50 rounded animate-pulse" />
                  </div>
                ) : (
                  <article className="prose prose-slate max-w-none">
                    <div className="flex items-center gap-2 mb-6 p-3 bg-green-50 text-green-700 rounded-xl text-xs font-black uppercase tracking-widest border border-green-100 w-fit">
                      <Zap className="w-4 h-4" /> Synthesized Logic: Y = !({expression})
                    </div>
                    <div className="whitespace-pre-wrap text-slate-600 text-sm sm:text-base font-medium leading-relaxed">
                      {explanation}
                    </div>
                  </article>
                )}
              </div>
            </div>

            <div className="p-6 bg-slate-900 rounded-2xl shadow-xl border border-slate-800">
              <h4 className="text-green-400 font-bold text-xs mb-3 flex items-center gap-2 uppercase tracking-widest">
                <Info className="w-4 h-4" /> Engineering Fundamentals
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Static CMOS gates are inherently inverting. To produce the logic {expression}, we construct a Pull-Down Network (PDN) using NMOS transistors that conduct when the result should be '0', and a dual Pull-Up Network (PUN) using PMOS transistors for '1'. The PDN follow standard boolean rules (Series for AND, Parallel for OR), while the PUN uses the De Morgan dual (Parallel for AND, Series for OR).
              </p>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
