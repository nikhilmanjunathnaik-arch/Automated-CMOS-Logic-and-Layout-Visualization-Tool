
import { LogicNode } from '../types';

export class LogicParser {
  private tokens: string[] = [];
  private pos = 0;

  parse(expression: string): LogicNode {
    let cleanExpr = expression
      .replace(/\s+/g, '')
      .replace(/XNOR/gi, '~')
      .replace(/XOR/gi, '^')
      .replace(/\|/g, '+')
      .replace(/&/g, '.');

    cleanExpr = this.expandComplexGates(cleanExpr);

    this.tokens = cleanExpr.split(/([.+!()])/).filter(t => t.length > 0);
    this.pos = 0;
    return this.parseExpression();
  }

  private expandComplexGates(expr: string): string {
    let result = expr;
    let prev;
    do {
      prev = result;
      result = result.replace(/([A-Z0-9!]+)\^([A-Z0-9!]+)/g, "($1.$2+!$1.!$2)");
      result = result.replace(/([A-Z0-9!]+)~([A-Z0-9!]+)/g, "($1.!$2+!$1.$2)");
    } while (result !== prev);
    return result;
  }

  private parseExpression(): LogicNode {
    let node = this.parseTerm();
    while (this.pos < this.tokens.length && this.tokens[this.pos] === '+') {
      this.pos++;
      const right = this.parseTerm();
      node = { type: 'OR', children: [node, right] };
    }
    return node;
  }

  private parseTerm(): LogicNode {
    let node = this.parseFactor();
    while (this.pos < this.tokens.length && this.tokens[this.pos] === '.') {
      this.pos++;
      const right = this.parseFactor();
      node = { type: 'AND', children: [node, right] };
    }
    return node;
  }

  private parseFactor(): LogicNode {
    if (this.pos >= this.tokens.length) return { type: 'VAR', value: '?' };
    const token = this.tokens[this.pos];
    if (token === '!') {
      this.pos++;
      return { type: 'NOT', children: [this.parseFactor()] };
    }
    if (token === '(') {
      this.pos++;
      const node = this.parseExpression();
      if (this.tokens[this.pos] === ')') this.pos++;
      return node;
    }
    this.pos++;
    return { type: 'VAR', value: token };
  }

  static getPDN(node: LogicNode): LogicNode {
    return node;
  }

  static getPUN(node: LogicNode): LogicNode {
    // Static CMOS uses the same tree structure, but handles duality at the layout level.
    // AND in PDN (Series NMOS) -> dual is Parallel PMOS.
    // OR in PDN (Parallel NMOS) -> dual is Series PMOS.
    return JSON.parse(JSON.stringify(node));
  }

  static evaluate(node: LogicNode, values: Record<string, boolean>): boolean {
    switch (node.type) {
      case 'VAR': return !!values[node.value || ''];
      case 'NOT': return !this.evaluate(node.children![0], values);
      case 'AND': return node.children!.every(c => this.evaluate(c, values));
      case 'OR': return node.children!.some(c => this.evaluate(c, values));
      default: return false;
    }
  }

  static getVariables(node: LogicNode): string[] {
    const vars = new Set<string>();
    const walk = (n: LogicNode) => {
      if (n.type === 'VAR' && n.value) vars.add(n.value);
      n.children?.forEach(walk);
    };
    walk(node);
    return Array.from(vars).sort();
  }
}
