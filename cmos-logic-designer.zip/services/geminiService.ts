
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function explainCMOS(expression: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Explain the CMOS implementation for the Boolean function Y = !(${expression}). 
      Describe:
      1. The Pull-Down Network (PDN) configuration (NMOS transistors).
      2. The Pull-Up Network (PUN) configuration (PMOS transistors) using duality.
      3. A brief summary of the logic.
      Keep it structured and technical but easy to understand for an undergrad student.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Could not generate AI explanation at this time.";
  }
}
