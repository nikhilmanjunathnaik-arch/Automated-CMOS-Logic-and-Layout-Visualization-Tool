
import React from 'react';
import { LogicNode } from '../types';

interface CircuitVisualizerProps {
  pun: LogicNode;
  pdn: LogicNode;
  expression: string;
}

const T_WIDTH = 50;
const T_HEIGHT = 70;
const COLOR = "#16a34a";

interface LayoutResult {
  width: number;
  height: number;
  centerX: number;
  node: React.ReactNode;
}

const PMOS: React.FC<{ x: number, y: number, label: string }> = ({ x, y, label }) => (
  <g>
    <line x1={x - 30} y1={y} x2={x - 13} y2={y} stroke={COLOR} strokeWidth="2" />
    <circle cx={x - 10} cy={y} r="3.5" fill="white" stroke={COLOR} strokeWidth="1.5" />
    <line x1={x - 5} y1={y - 18} x2={x - 5} y2={y + 18} stroke={COLOR} strokeWidth="2.5" />
    <line x1={x} y1={y - 18} x2={x} y2={y + 18} stroke={COLOR} strokeWidth="2.5" />
    <line x1={x} y1={y - 15} x2={x + 5} y2={y - 15} stroke={COLOR} strokeWidth="2" />
    <line x1={x} y1={y + 15} x2={x + 5} y2={y + 15} stroke={COLOR} strokeWidth="2" />
    <line x1={x + 5} y1={y - 35} x2={x + 5} y2={y - 15} stroke={COLOR} strokeWidth="2" />
    <line x1={x + 5} y1={y + 15} x2={x + 5} y2={y + 35} stroke={COLOR} strokeWidth="2" />
    <text x={x - 35} y={y + 5} fontSize="13" fontWeight="bold" fill={COLOR} textAnchor="end" className="mono">{label}</text>
  </g>
);

const NMOS: React.FC<{ x: number, y: number, label: string }> = ({ x, y, label }) => (
  <g>
    <line x1={x - 30} y1={y} x2={x - 5} y2={y} stroke={COLOR} strokeWidth="2" />
    <line x1={x - 5} y1={y - 18} x2={x - 5} y2={y + 18} stroke={COLOR} strokeWidth="2.5" />
    <line x1={x} y1={y - 18} x2={x} y2={y + 18} stroke={COLOR} strokeWidth="2.5" />
    <line x1={x} y1={y - 15} x2={x + 5} y2={y - 15} stroke={COLOR} strokeWidth="2" />
    <line x1={x} y1={y + 15} x2={x + 5} y2={y + 15} stroke={COLOR} strokeWidth="2" />
    <line x1={x + 5} y1={y - 35} x2={x + 5} y2={y - 15} stroke={COLOR} strokeWidth="2" />
    <line x1={x + 5} y1={y + 15} x2={x + 5} y2={y + 35} stroke={COLOR} strokeWidth="2" />
    <text x={x - 35} y={y + 5} fontSize="13" fontWeight="bold" fill={COLOR} textAnchor="end" className="mono">{label}</text>
  </g>
);

export const CircuitVisualizer: React.FC<CircuitVisualizerProps> = ({ pun, pdn, expression }) => {
  
  const buildLayout = (node: LogicNode, isPUN: boolean): LayoutResult => {
    if (node.type === 'VAR' || node.type === 'NOT') {
      const label = node.type === 'NOT' ? `!${node.children?.[0].value}` : node.value || '?';
      return {
        width: T_WIDTH + 60,
        height: T_HEIGHT,
        centerX: 35,
        node: isPUN ? <PMOS x={30} y={35} label={label} /> : <NMOS x={30} y={35} label={label} />
      };
    }

    // Static CMOS Rules:
    // PDN: AND = Series, OR = Parallel
    // PUN: AND = Parallel, OR = Series
    const isSeries = (isPUN && node.type === 'OR') || (!isPUN && node.type === 'AND');
    const childrenLayouts = node.children?.map(c => buildLayout(c, isPUN)) || [];

    if (isSeries) {
      let totalHeight = 0;
      let maxWidth = 0;
      childrenLayouts.forEach(l => {
        totalHeight += l.height;
        maxWidth = Math.max(maxWidth, l.width);
      });

      let currentY = 0;
      const childNodes = childrenLayouts.map((l, i) => {
        const xOffset = (maxWidth / 2) - l.centerX;
        const res = <g transform={`translate(${xOffset}, ${currentY})`} key={i}>{l.node}</g>;
        currentY += l.height;
        return res;
      });

      return {
        width: maxWidth,
        height: totalHeight,
        centerX: maxWidth / 2,
        node: <g>{childNodes}</g>
      };
    } else {
      let totalWidth = 0;
      let maxHeight = 0;
      const GAP = 25;
      childrenLayouts.forEach(l => {
        totalWidth += l.width + GAP;
        maxHeight = Math.max(maxHeight, l.height);
      });
      totalWidth -= GAP;

      let currentX = 0;
      const groupComponents: React.ReactNode[] = [];
      const commonLeadX = totalWidth / 2;

      // Draw horizontal bars for Figure 2 style
      const bars = [
        <line x1={childrenLayouts[0].centerX} y1={0} x2={currentX + totalWidth - childrenLayouts[childrenLayouts.length-1].width + childrenLayouts[childrenLayouts.length-1].centerX} y2={0} stroke={COLOR} strokeWidth="2" key="t-bar" />,
        <line x1={childrenLayouts[0].centerX} y1={maxHeight} x2={currentX + totalWidth - childrenLayouts[childrenLayouts.length-1].width + childrenLayouts[childrenLayouts.length-1].centerX} y2={maxHeight} stroke={COLOR} strokeWidth="2" key="b-bar" />,
        // Center connect
        <line x1={commonLeadX} y1={-20} x2={commonLeadX} y2={0} stroke={COLOR} strokeWidth="2" key="t-conn" />,
        <line x1={commonLeadX} y1={maxHeight} x2={commonLeadX} y2={maxHeight + 20} stroke={COLOR} strokeWidth="2" key="b-conn" />
      ];

      const components = childrenLayouts.map((l, i) => {
        const xPos = currentX;
        const res = <g transform={`translate(${xPos}, 0)`} key={`node-${i}`}>{l.node}</g>;
        currentX += l.width + GAP;
        return res;
      });

      return {
        width: totalWidth,
        height: maxHeight + 40,
        centerX: commonLeadX,
        node: <g transform="translate(0, 20)">{components}{bars}</g>
      };
    }
  };

  const punLayout = buildLayout(pun, true);
  const pdnLayout = buildLayout(pdn, false);

  const SVG_WIDTH = Math.max(punLayout.width, pdnLayout.width, 400) + 120;
  const SVG_HEIGHT = punLayout.height + pdnLayout.height + 250;

  return (
    <div className="bg-white p-6 rounded-2xl shadow-xl border border-slate-200 overflow-auto flex justify-center">
      <svg width={SVG_WIDTH} height={SVG_HEIGHT} viewBox={`0 0 ${SVG_WIDTH} ${SVG_HEIGHT}`}>
        {/* VDD Bar */}
        <line x1={SVG_WIDTH/2 - 50} y1={30} x2={SVG_WIDTH/2 + 50} y2={30} stroke={COLOR} strokeWidth="3" />
        <line x1={SVG_WIDTH/2} y1={30} x2={SVG_WIDTH/2} y2={60} stroke={COLOR} strokeWidth="2" />
        <text x={SVG_WIDTH/2 + 60} y={35} fontSize="16" fontWeight="bold" fill={COLOR}>VDD</text>

        {/* PUN Section */}
        <g transform={`translate(${SVG_WIDTH/2 - punLayout.centerX}, 60)`}>
          {punLayout.node}
        </g>

        {/* Output Node Node */}
        <g transform={`translate(${SVG_WIDTH/2}, ${60 + punLayout.height})`}>
          <line x1="0" y1="0" x2="0" y2="60" stroke={COLOR} strokeWidth="2" />
          <circle cx="0" cy="30" r="5" fill={COLOR} />
          <line x1="0" y1="30" x2="100" y2="30" stroke={COLOR} strokeWidth="2" />
          <text x={110} y={35} fontSize="18" fontWeight="bold" fill={COLOR} className="mono italic">
            Y = <tspan style={{ textDecoration: 'overline' }}>{expression.replace(/\^/g, '⊕').replace(/~/g, '⊙').replace(/\*/g, '').replace(/\./g, '')}</tspan>
          </text>
        </g>

        {/* PDN Section */}
        <g transform={`translate(${SVG_WIDTH/2 - pdnLayout.centerX}, ${120 + punLayout.height})`}>
          {pdnLayout.node}
        </g>

        {/* GND Symbol */}
        <g transform={`translate(${SVG_WIDTH/2}, ${120 + punLayout.height + pdnLayout.height})`}>
           <line x1="0" y1="0" x2="0" y2="20" stroke={COLOR} strokeWidth="2" />
           <line x1="-30" y1="20" x2="30" y2="20" stroke={COLOR} strokeWidth="3" />
           <line x1="-18" y1="28" x2="18" y2="28" stroke={COLOR} strokeWidth="2" />
           <line x1="-8" y1="36" x2="8" y2="36" stroke={COLOR} strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
};
