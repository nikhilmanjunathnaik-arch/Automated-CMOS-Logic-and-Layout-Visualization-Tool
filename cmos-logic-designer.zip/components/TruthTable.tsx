
import React from 'react';
import { LogicNode } from '../types';
import { LogicParser } from '../services/logicParser';

interface TruthTableProps {
  root: LogicNode;
}

export const TruthTable: React.FC<TruthTableProps> = ({ root }) => {
  const vars = LogicParser.getVariables(root);
  const rows = Math.pow(2, vars.length);
  const tableData: Array<{ inputs: Record<string, boolean>; output: boolean }> = [];

  for (let i = 0; i < rows; i++) {
    const inputs: Record<string, boolean> = {};
    vars.forEach((v, idx) => {
      inputs[v] = !!((i >> (vars.length - 1 - idx)) & 1);
    });
    // The output is !expression for Static CMOS
    tableData.push({ inputs, output: !LogicParser.evaluate(root, inputs) });
  }

  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 shadow-sm bg-white">
      <table className="w-full text-sm text-left border-collapse">
        <thead className="bg-slate-50 border-b border-slate-200">
          <tr>
            {vars.map(v => (
              <th key={v} className="px-4 py-3 font-bold text-slate-700 uppercase tracking-wider border-r border-slate-200">
                {v}
              </th>
            ))}
            <th className="px-4 py-3 font-bold text-green-700 uppercase tracking-wider bg-green-50">
              Y (Out)
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {tableData.map((row, idx) => (
            <tr key={idx} className="hover:bg-slate-50 transition-colors">
              {vars.map(v => (
                <td key={v} className="px-4 py-2 border-r border-slate-200 mono font-medium">
                  {row.inputs[v] ? '1' : '0'}
                </td>
              ))}
              <td className="px-4 py-2 bg-green-50/30 mono font-bold text-green-600">
                {row.output ? '1' : '0'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
